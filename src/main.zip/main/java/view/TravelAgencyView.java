package view;

public class TravelAgencyView {
}
