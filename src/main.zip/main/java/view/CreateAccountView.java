package view;
import javax.swing.*;
import java.awt.*;

public class CreateAccountView extends AppFrame {
    private JButton createAccountButton;
    private JTextField patientFullNameTextField;
    private JTextField patientPhoneTextField;
    private JTextField patientEmailTextField;
    private JPasswordField patientPasswordTextField;


    public CreateAccountView() {
        initialize();
    }

    public void initialize() {
        this.setTitle("Create Account");
        this.setSize(500, 400);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLayout(null);

        this.setResizable(false);
        this.setLocationRelativeTo(null);
        JPanel panel = new JPanel();
        panel.setLayout(null);

        initializeForm(panel);

        panel.setBackground(new Color(199,201,255));
        this.setContentPane(panel);
        this.setVisible(true);
    }

    private void initializeForm(JPanel panel) {
        JLabel patientFullNameLabel = new JLabel("Full name:");
        patientFullNameLabel.setBounds(150, 30, 200, 30);

        patientFullNameTextField = new JTextField();
        patientFullNameTextField.setBounds(150, 60, 200, 30);

        JLabel patientPhoneLabel = new JLabel("Phone:");
        patientPhoneLabel.setBounds(150, 90, 200, 30);

        patientPhoneTextField = new JTextField();
        patientPhoneTextField.setBounds(150, 120, 200, 30);

        JLabel patientEmailLabel = new JLabel("Email address:");
        patientEmailLabel.setBounds(150,150,200,30);

        patientEmailTextField = new JTextField();
        patientEmailTextField.setBounds(150,180,200,30);

        JLabel patientPasswordLabel = new JLabel("Password:");
        patientPasswordLabel.setBounds(150,210,200,30);

        patientPasswordTextField =  new JPasswordField();
        patientPasswordTextField.setBounds(150,240,200,30);
        patientPasswordTextField.setEchoChar('*');

        createAccountButton = new JButton("Create account");
        createAccountButton.setBounds(150, 300, 200, 30);

        panel.add(createAccountButton);
        panel.add(patientFullNameLabel);
        panel.add(patientFullNameTextField);
        panel.add(patientPhoneLabel);
        panel.add(patientPhoneTextField);
        panel.add(patientEmailLabel);
        panel.add(patientEmailTextField);
        panel.add(patientPasswordLabel);
        panel.add(patientPasswordTextField);

    }


}
