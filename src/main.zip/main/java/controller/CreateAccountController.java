package controller;

import view.CreateAccountView;

public class CreateAccountController {
    private CreateAccountView createView;
    public CreateAccountController(){
        createView = new CreateAccountView();
    }

}
