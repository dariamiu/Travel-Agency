package controller;

import service.UserService;
import view.LoginView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginController {

    private UserService userService;
    private LoginView loginView;

    public LoginController(){
        userService = new UserService();
        loginView = new LoginView();
        actions();
    }

    private void actions() {
        loginView.createActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new CreateAccountController();
            }
        });
    }

}
