package repository;

import model.Destination;
import model.User;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;

public class DestinationRepository {
    private final EntityManagerFactory entityManagerFactory =
            Persistence.createEntityManagerFactory("travel_agency");

    public void insertDestination(Destination destination){
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        em.persist(destination);
        em.getTransaction().commit();
        em.close();
    }

    public void deleteDestination(String name){
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        try{
            em.createQuery(
                    "DELETE FROM Destination WHERE Destination.name = :name", Destination.class).setParameter("name",name).getSingleResult();
        }catch (NoResultException e){
            System.out.println("No destination found");
        }
        em.getTransaction().commit();
        em.close();

    }

    public void updateDetails(String description){
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        try{
            em.createQuery(
                    "UPDATE Destination SET Destination.description = :description WHERE Destination.name = :name", Destination.class).setParameter("description",description).getSingleResult();
        }catch (NoResultException e){
            System.out.println("No destination found");
        }
        em.getTransaction().commit();
        em.close();

    }

    public Destination findByName(String name){
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        try{
            return em.createQuery(
                    "SELECT u from Destination u WHERE u.name = :name", Destination.class).setParameter("name",name).getSingleResult();
        }catch (NoResultException e){
            System.out.println("No destination found");
        }
        em.getTransaction().commit();
        em.close();
        return null;
    }

}
