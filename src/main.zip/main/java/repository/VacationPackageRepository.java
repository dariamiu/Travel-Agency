package repository;

import model.Destination;
import model.VacationPackage;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;

public class VacationPackageRepository {
    private final EntityManagerFactory entityManagerFactory =
            Persistence.createEntityManagerFactory("travel_agency");

    public void insertVacation(VacationPackage vacationPackage){
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        em.persist(vacationPackage);
        em.getTransaction().commit();
        em.close();
    }

    public VacationPackage findByDestinationName(String name){
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        try{
            return em.createQuery(
                    "SELECT u from VacationPackage u WHERE u.destination.name = :name", VacationPackage.class).setParameter("name",name).getSingleResult();
        }catch (NoResultException e){
            System.out.println("No vacation found");
        }
        em.getTransaction().commit();
        em.close();
        return null;
    }

    public VacationPackage findByName(String name){
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        try{
            return em.createQuery(
                    "SELECT u from VacationPackage u WHERE u.name = :name", VacationPackage.class).setParameter("name",name).getSingleResult();
        }catch (NoResultException e){
            System.out.println("No vacation found");
        }
        em.getTransaction().commit();
        em.close();
        return null;
    }


    public void deleteVacationPackageByDestination(String name){
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        try{
            em.createQuery(
                    "DELETE FROM VacationPackage WHERE VacationPackage.destination.name = :name", VacationPackage.class).setParameter("name",name).getSingleResult();
        }catch (NoResultException e){
            System.out.println("No destination found");
        }
        em.getTransaction().commit();
        em.close();

    }

    public void deleteVacationPackageByName(String name){
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        try{
            em.createQuery(
                    "DELETE FROM VacationPackage WHERE VacationPackage.id_vacation = :name", VacationPackage.class).setParameter("name", name).getSingleResult();
        }catch (NoResultException e){
            System.out.println("No vacation found");
        }
        em.getTransaction().commit();
        em.close();

    }

    public void updateDetails(String description){
        EntityManager em = entityManagerFactory.createEntityManager();
        em.getTransaction().begin();
        try{
            em.createQuery(
                    "UPDATE Destination SET Destination.description = :description WHERE Destination.name = :name", Destination.class).setParameter("description",description).getSingleResult();
        }catch (NoResultException e){
            System.out.println("No destination found");
        }
        em.getTransaction().commit();
        em.close();

    }

}
