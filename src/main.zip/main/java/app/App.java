package app;

import controller.LoginController;
import model.Destination;
import model.VacationPackage;
import repository.DestinationRepository;
import repository.UserRepository;
import repository.VacationPackageRepository;
import service.DestinationService;
import service.UserService;
import service.VacationPackageService;
import view.StartView;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.time.LocalDate;

public class App {

    private static final EntityManagerFactory entityManagerFactory =
            Persistence.createEntityManagerFactory("travel_agency");

    public static void main(String[] args) {
        UserRepository userRepository = new UserRepository();
        UserService userService = new UserService();
        //userRepository.insertUser(new User("Daria Miu","miumiu@gmail.com","alabala", "0711111111"));
        //userService.createUser(new User("Ariana Horvath","ariari@gmail.com","alabala", "0722222222"));
        //User user1 = userRepository.findByUsername("ariari@gmail.com");
        //User user2 = userService.getUserByEmail("ariari@gmail.com");
        //User user3 = userService.getUserByEmail("kkk");
        //System.out.println(user1.getFullName());
        //System.out.println(user2.getFullName());
        //System.out.println(user3.getFullName());

        //DestinationRepository destinationRepository = new DestinationRepository();
        //DestinationService destinationService = new DestinationService();
       // destinationRepository.insertDestination(new Destination("Ibiza","very very beautiful and cheap"));
       // Destination destination1 = destinationRepository.findByName("Ibiza");
        //destinationService.createDestination(new Destination("Valencia", "incredible"));
       // Destination destination2 = destinationService.getByName("Valencia");
       // Destination destination3 = destinationService.getByName("Madrid");

      //  System.out.println(destination1.getDescription());
        /*System.out.println(destination2.getDescription());
        if(destination3 == null){
            System.out.println("of nu");
        }else {
            System.out.println(destination3.getDescription());
        }*/

       // VacationPackageService vacationPackageService = new VacationPackageService();



/*
        VacationPackageRepository vacationPackageRepository = new VacationPackageRepository();
        VacationPackage vacationPackage = new VacationPackage(300.0f, 25, 0,LocalDate.of(2022,5,21) ,
                LocalDate.of(2022,5,27) , "NOT_BOOKED", destination1);
        vacationPackageRepository.insertVacation(vacationPackage);
        VacationPackage vacationPackage1 = vacationPackageRepository.findByDestinationName("Ibiza");
        System.out.println(vacationPackage1.getDestination().getName() + " " + vacationPackage.getPrice());
*/
        new StartView();
    }
}
