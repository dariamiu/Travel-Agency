package validator;

public class VacationPackageValidator {
}
