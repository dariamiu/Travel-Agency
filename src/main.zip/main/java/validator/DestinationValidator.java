package validator;

public class DestinationValidator {
}
