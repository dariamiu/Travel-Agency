package service;

import model.Destination;
import repository.DestinationRepository;

public class DestinationService {
    private final DestinationRepository destinationRepository;

    public DestinationService(){
        destinationRepository = new DestinationRepository();
    }

    public void createDestination(Destination destination){
        destinationRepository.insertDestination(destination);
    }

    public Destination getByName(String name){
        return destinationRepository.findByName(name);
    }


    public void deleteDestination(String name){
        destinationRepository.deleteDestination(name);
    }

    public void updateDescription(String description){
        destinationRepository.updateDetails(description);
    }


}
