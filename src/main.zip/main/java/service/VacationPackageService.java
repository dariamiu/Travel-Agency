package service;
import model.VacationPackage;
import repository.VacationPackageRepository;

public class VacationPackageService {
    private final VacationPackageRepository vacationPackageRepository;

    public VacationPackageService(){
        vacationPackageRepository = new VacationPackageRepository();
    }

    public void createDestination(VacationPackage vacationPackage){
        vacationPackageRepository.insertVacation(vacationPackage);
    }

    public VacationPackage getByDestinationName(String name){
        return vacationPackageRepository.findByDestinationName(name);
    }

    public VacationPackage getByName(String name){
        return vacationPackageRepository.findByName(name);
    }

    public void deleteByDestination(String name){
        vacationPackageRepository.deleteVacationPackageByDestination(name);
    }

    public void deleteByName(String name){
        vacationPackageRepository.deleteVacationPackageByName(name);
    }
}
